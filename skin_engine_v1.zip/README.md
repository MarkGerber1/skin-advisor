
# Skin Engine v1

Готовый движок для бота Skin Advisor: каталог → подбор (15 декор / 7 уход) → приоритет источников → PDF.

## Установка
```bash
pip install pydantic fpdf2
```

## Быстрый старт
```python
from engine import CatalogLoader, select_products, build_pdf_report, UserProfile

# 1) загрузка каталога (ожидаются 3 файла в content/catalog/*.json)
loader = CatalogLoader(base_path="content/catalog", availability_mode="only_in_stock")
catalog = loader.load()

# 2) профиль пользователя
user = UserProfile(user_id=1, name="Анна", age=28, gender="f",
                   season="summer", undertone="cool", eye_color="green",
                   skin_type="combo", dehydrated=True, concerns=["blackheads","redness"])

# 3) подбор
payload = select_products(user, catalog)

# 4) PDF (полный отчёт)
path = build_pdf_report(user.model_dump(), payload, out_path="data/reports/1/last.pdf", font_path="assets/fonts/DejaVuSans.ttf")
print("PDF:", path)
```

## Примечания
- Приоритет источников: GP → GP-like → WB/Ozon.
- Режим `only_in_stock` фильтрует отсутствующие позиции, замена выполняется на уровне селектора за счёт ранжирования.
- При ничьей по сезону выводится `_tie_breaker` с уточняющими вопросами.
