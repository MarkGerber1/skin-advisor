
from __future__ import annotations
from typing import Dict, List, Any, Optional
import os

def build_pdf_report(user_profile: dict, selection: dict, out_path: str, font_path: str = "assets/fonts/DejaVuSans.ttf") -> str:
    """Генерирует PDF-отчёт (максимально полный) на русском.
    Требует fpdf2. Если fpdf2 недоступен — сохраняет .md рядом как fallback.
    Структура: титул -> предыстория (почему так) -> описание (цветотип/кожа) ->
    рекомендации -> что купить (с изображениями, если возможно).
    """
    try:
        from fpdf import FPDF
    except Exception:
        # Fallback: текстовый markdown
        md = _render_markdown(user_profile, selection)
        if not out_path.endswith(".pdf"):
            out_path += ".pdf"
        md_path = out_path.replace(".pdf",".md")
        os.makedirs(os.path.dirname(md_path), exist_ok=True)
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(md)
        return md_path

    pdf = FPDF(unit="mm", format="A4")
    pdf.add_page()
    try:
        pdf.add_font("DejaVu", "", font_path, uni=True)
        pdf.set_font("DejaVu", size=14)
    except Exception:
        pdf.set_font("Arial", size=14)

    def h(txt): 
        pdf.set_font_size(16); pdf.multi_cell(0, 8, txt); pdf.ln(2); pdf.set_font_size(12)

    # Титул
    pdf.set_font_size(20)
    pdf.multi_cell(0, 10, "Отчёт Skin Advisor — персональные рекомендации")
    pdf.ln(3)
    pdf.set_font_size(12)
    info = f"Профиль: {user_profile.get('name','')}  |  Возраст: {user_profile.get('age','?')}  |  Пол: {user_profile.get('gender','?')}"
    pdf.multi_cell(0, 6, info); pdf.ln(2)

    # Предыстория / Почему так
    h("Почему именно такие выводы")
    because = []
    if user_profile.get("dehydrated"): because.append("Выявлена обезвоженность → усиливаем увлажнение и окклюзию.")
    if user_profile.get("sensitivity") in ("mid","high"): because.append("Повышенная чувствительность → избегаем агрессивных кислот и отдушек.")
    if user_profile.get("uses_retinoids"): because.append("Используются ретиноиды → осторожно с AHA/BHA.")
    if not because: because.append("На основе ответов анкеты и анализа цветотипа/состояния кожи.")
    for line in because:
        pdf.multi_cell(0, 6, f"• {line}")

    # Описание цветотипа/кожи
    h("Краткий портрет")
    season = user_profile.get("season")
    undertone = user_profile.get("undertone")
    skin = user_profile.get("skin_type")
    pdf.multi_cell(0, 6, f"Цветотип: {season or '—'}; Подтон: {undertone or '—'}; Тип кожи: {skin or '—'}.")
    if user_profile.get("season_alt"):
        pdf.multi_cell(0, 6, f"Пограничный результат между: {season} и {user_profile.get('season_alt')} — даны обе палитры.")

    # Рекомендации по уходу/макияжу
    h("Рекомендации (день/вечер)")
    pdf.multi_cell(0, 6, "• Утро: очищение → увлажнение/сыворотка → крем → SPF → макияж.")
    pdf.multi_cell(0, 6, "• Вечер: очищение → актив (AHA/BHA/ретиноид*) → крем; *с учётом противопоказаний.")

    # Что купить — карточки
    h("Что купить (подборка InStock)")
    def block(items: List[dict], title: str):
        pdf.set_font_size(14); pdf.multi_cell(0, 7, title); pdf.ln(1); pdf.set_font_size(11)
        for it in items:
            line = f"{it.get('title','')} — {it.get('display_price','Цена на странице магазина')}"
            pdf.multi_cell(0, 5, line)
            if it.get('summary_ru'):
                pdf.multi_cell(0, 5, f"  {it['summary_ru']}")
            pdf.ln(1)
    block(selection.get("decor", [])[:20], "Декоративная косметика")
    block(selection.get("care", [])[:20], "Уходовая косметика")

    out_dir = os.path.dirname(out_path)
    os.makedirs(out_dir, exist_ok=True)
    pdf.output(out_path)
    return out_path

def _render_markdown(user_profile: dict, selection: dict) -> str:
    return """# Отчёт Skin Advisor (fallback)

Этот файл создан как запасной вариант, так как библиотека fpdf2 недоступна в окружении.

## Профиль
- Имя: {name}
- Возраст: {age}
- Пол: {gender}
- Цветотип: {season} (альтернатива: {season_alt})
- Подтон: {undertone}
- Тип кожи: {skin_type}

## Рекомендации (кратко)
- Утро: очищение → сыворотка/крем → SPF → макияж
- Вечер: очищение → актив (AHA/BHA/ретиноид*) → крем

## Декор (InStock)
{decor}

## Уход (InStock)
{care}
""".format(
        name=user_profile.get("name",""),
        age=user_profile.get("age","?"),
        gender=user_profile.get("gender","?"),
        season=user_profile.get("season","—"),
        season_alt=user_profile.get("season_alt","—"),
        undertone=user_profile.get("undertone","—"),
        skin_type=user_profile.get("skin_type","—"),
        decor="\n".join(f"- {it.get('title','')}: {it.get('display_price','')}" for it in selection.get("decor",[])[:20]),
        care="\n".join(f"- {it.get('title','')}: {it.get('display_price','')}" for it in selection.get("care",[])[:20]),
    )
