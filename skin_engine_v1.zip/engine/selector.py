
from __future__ import annotations
from typing import Dict, List, Tuple, Iterable
from .models import UserProfile, Product

# 15 категорий декора
DECOR_CATS = [
    "tone","concealer","corrector","powder","blush","bronzer","sculptor","highlighter",
    "brow_gel","brow_pencil","mascara","eyeshadow","kajal","lip_color","lip_liner"
]
# 7 категорий ухода
CARE_CATS = ["cleanser","toner_exfo","treatment","eye_cream","primer","extra_spf_mask","makeup_remover"]

SOURCE_PRIORITY = {"gp": 1, "gp_like": 2, "wb": 3, "ozon": 3}

# Простое правило оттенков по сезону/подтону
SEASON_TONE_PREF = {
    "spring": {"tone_family": "warm", "finish": ["dewy","natural"]},
    "summer": {"tone_family": "cool", "finish": ["natural","satin"]},
    "autumn": {"tone_family": "warm", "finish": ["matte","satin"]},
    "winter": {"tone_family": "cool", "finish": ["matte","velvet"]},
}

EYES_COMPLEMENT = {
    "green": ["plum","taupe","copper","bronze"],
    "brown": ["gold","bronze","violet","navy"],
    "blue":  ["warm_brown","peach","taupe","burgundy"],
    "gray":  ["mauve","charcoal","cool_taupe"],
    "hazel": ["olive","gold","bronze","eggplant"],
}

def _source_rank(p: Product) -> int:
    return SOURCE_PRIORITY.get(p.source or "gp", 99)

def _score_decor(p: Product, user: UserProfile) -> float:
    s = 0.0
    # Источник/наличие
    s -= 0.05 * _source_rank(p)
    if not p.in_stock:
        s -= 5.0
    # Сезон/подтон
    if user.season and p.tone_family and SEASON_TONE_PREF.get(user.season, {}).get("tone_family") == p.tone_family:
        s += 1.0
    if user.undertone and p.tone_family and user.undertone != "unknown":
        if user.undertone == p.tone_family:
            s += 0.8
    # Контраст → допускаем более «чистые»/матовые для high
    if user.contrast == "high" and p.finish in ("matte","velvet","pure"):
        s += 0.3
    # Глаза → палитры теней/карандашей
    if p.category in ("eyeshadow","kajal") and user.eye_color:
        hints = EYES_COMPLEMENT.get(user.eye_color, [])
        # простая эвристика: совпадение по тэгам/оттенку в названии
        name = (p.title or "").lower()
        if any(h in name for h in hints):
            s += 0.6
    # Брови: карандаш/гель ±1 тон — проксимально через название
    if p.category in ("brow_pencil","brow_gel") and user.brow_color:
        name = (p.title or "").lower()
        if user.brow_color.lower() in name:
            s += 0.5
    return s

def _score_care(p: Product, user: UserProfile) -> float:
    s = 0.0
    if not p.in_stock:
        return -5.0
    # Тип кожи
    if user.skin_type and user.skin_type in (p.tags or set()):
        s += 0.6
    # Дехидратация/чувствительность
    if user.dehydrated and "ceramides" in (p.actives or []):
        s += 0.4
    if (user.sensitivity in ("mid","high")) and ("fragrance" in (p.allergenic_flags or set())):
        s -= 1.0
    # Консерн-наводки (просто ключевые слова actives)
    for c, act in {
        "blackheads":"bha",
        "acne":"bha",
        "pigmentation":"niacinamide",
        "wrinkles":"retinoid",
        "redness":"azelaic",
    }.items():
        if c in (user.concerns or []) and act in (p.actives or []):
            s += 0.6
    # SPF при дневных сценариях
    name = (p.title or "").lower()
    if p.category in ("extra_spf_mask","primer") and ("spf" in name or "sunscreen" in name):
        s += 0.5
    return s

def _pick_top_by_category(catalog: Dict[str, Product], cat: str, k: int, scorer, user: UserProfile) -> List[Product]:
    cands = [p for p in catalog.values() if p.category == cat]
    # сортировка: по скору, затем по источнику
    ranked = sorted(cands, key=lambda p: (scorer(p, user), - (100 - _source_rank(p))), reverse=True)
    out: List[Product] = []
    seen_sources = set()
    for p in ranked:
        if not p.in_stock:
            continue
        # разнообразим по источнику/цене (если price есть)
        key = (p.source or "gp", "mid" if not p.price else ("budget" if p.price < 1500 else "premium" if p.price > 5000 else "mid"))
        if key in seen_sources:
            continue
        out.append(p)
        seen_sources.add(key)
        if len(out) >= k:
            break
    return out

def select_decorative(user: UserProfile, catalog: Dict[str, Product]) -> List[Product]:
    out: List[Product] = []
    for cat in DECOR_CATS:
        picked = _pick_top_by_category(catalog, cat, k=3 if cat in ("tone","eyeshadow","lip_color") else 2, scorer=_score_decor, user=user)
        out.extend(picked)
    return out

def select_care(user: UserProfile, catalog: Dict[str, Product]) -> List[Product]:
    out: List[Product] = []
    for cat in CARE_CATS:
        picked = _pick_top_by_category(catalog, cat, k=2, scorer=_score_care, user=user)
        out.extend(picked)
    return out

def select_products(user: UserProfile, catalog: Dict[str, Product]) -> Dict[str, List[dict]]:
    decor = [p.model_dump() for p in select_decorative(user, catalog)]
    care  = [p.model_dump() for p in select_care(user, catalog)]
    # Если ничья по сезону — добавим пометку в payload (UI-слой покажет 2 палитры/уточняющие вопросы)
    payload = {"decor": decor, "care": care}
    if user.season_alt:
        payload["_tie_breaker"] = {
            "season": user.season,
            "season_alt": user.season_alt,
            "ask": ["Как ведёт себя кожа на солнце? (загар/ожоги)", "Золото или серебро подходит больше?" ]
        }
    return payload
