
from __future__ import annotations
from typing import Optional, Literal, List, Dict, Set
from pydantic import BaseModel, Field

Season = Literal["spring","summer","autumn","winter"]
Undertone = Literal["warm","cool","neutral","unknown"]

class UserProfile(BaseModel):
    user_id: int
    name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[Literal["f","m","x"]] = None
    # Палитра (A)
    season: Optional[Season] = None
    season_alt: Optional[Season] = None  # при ничьей
    undertone: Optional[Undertone] = "unknown"
    hair_color: Optional[str] = None
    brow_color: Optional[str] = None
    eye_color: Optional[str] = None
    contrast: Optional[Literal["low","medium","high"]] = None
    # Кожа (B)
    skin_type: Optional[Literal["dry","normal","combo","oily"]] = None
    dehydrated: Optional[bool] = None
    sensitivity: Optional[Literal["low","mid","high"]] = None
    concerns: List[str] = Field(default_factory=list)  # ["blackheads","acne","pigmentation","redness","wrinkles"]
    pore_size: Optional[Literal["small","medium_tzone","large_cheeks_nose","very_large"]] = None
    uses_retinoids: Optional[bool] = None
    pregnant_or_lactating: Optional[bool] = None

DecorCategory = Literal[
  "tone","concealer","corrector","powder","blush","bronzer","sculptor","highlighter",
  "brow_gel","brow_pencil","mascara","eyeshadow","kajal","lip_color","lip_liner"
]

CareCategory = Literal[
  "cleanser","toner_exfo","treatment","eye_cream","primer","extra_spf_mask","makeup_remover"
]

class Product(BaseModel):
    key: str                     # нормализованный ключ
    title: str                   # бренд + товар
    brand: Optional[str] = None
    category: str                # DecorCategory | CareCategory
    shade: Optional[str] = None  # для декора
    summary_ru: Optional[str] = None
    usage_ru: Optional[str] = None
    price: Optional[float] = None
    display_price: Optional[str] = None
    in_stock: bool = False
    buy_url: Optional[str] = None
    source: Optional[Literal["gp","gp_like","wb","ozon"]] = None
    image_url: Optional[str] = None
    # оттеночные/формульные признаки
    tone_family: Optional[Literal["warm","cool","neutral"]] = None
    depth: Optional[int] = None  # 1..10
    finish: Optional[str] = None # matte/dewy/...
    actives: List[str] = Field(default_factory=list)  # care: ["niacinamide","bha",...]
    tags: Set[str] = Field(default_factory=set)       # ["mineral","fragrance_free",...]
    allergenic_flags: Set[str] = Field(default_factory=set) # ["fragrance","alcohol_denat"]
    usage: Optional[Literal["AM","PM","weekly"]] = None
