
from __future__ import annotations
import json, time
from typing import Dict, Any
from .models import Product

def normalize_key(s: str) -> str:
    return "".join(ch.lower() for ch in s if ch.isalnum() or ch in ("-","_")).strip("_-")

class CatalogLoader:
    def __init__(self, base_path: str = "content/catalog", availability_mode: str = "only_in_stock"):
        self.base_path = base_path
        self.availability_mode = availability_mode
        self._cache: Dict[str, Any] = {}
        self._ts: float = 0.0

    def _read_json(self, fname: str) -> Any:
        path = f"{self.base_path}/{fname}"
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def load(self, force: bool = False) -> Dict[str, Product]:
        # простой кеш на процесс
        if self._cache and not force:
            return self._cache
        desc = self._read_json("catalog_descriptions.json")
        links = self._read_json("catalog_links.json")
        prices = self._read_json("catalog_prices.json")

        by_key: Dict[str, Product] = {}
        # Ожидаем словари {key: {...}}
        keys = set(desc.keys()) | set(links.keys()) | set(prices.keys())
        for k in keys:
            d = desc.get(k, {})
            l = links.get(k, {})
            p = prices.get(k, {})
            prod = Product(
                key=k,
                title=d.get("title") or d.get("name") or k,
                brand=d.get("brand"),
                category=d.get("category") or d.get("cat") or "",
                shade=d.get("shade"),
                summary_ru=d.get("summary_ru"),
                usage_ru=d.get("usage_ru"),
                price=p.get("_price"),
                display_price=str(p.get("_price")) if p.get("_price") else "Цена на странице магазина",
                in_stock=bool(p.get("in_stock", False)),
                buy_url=l.get("_ga_url") or l.get("_ga_query"),
                source=l.get("_source") or "gp",
                image_url=d.get("image_url"),
                tone_family=d.get("tone_family"),
                depth=d.get("depth"),
                finish=d.get("finish"),
                actives=d.get("actives", []),
                tags=set(d.get("tags", [])),
                allergenic_flags=set(d.get("allergenic_flags", [])),
                usage=d.get("usage") or d.get("when"),
            )
            # Фильтр по наличию
            if self.availability_mode == "only_in_stock" and not prod.in_stock:
                # пропускаем из выдачи, но в каталоге держим
                pass
            by_key[k] = prod

        # сортировка/приоритет источников — хранится в поле source при отборе
        self._cache = by_key
        self._ts = time.time()
        return self._cache
